import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { createBrowserHistory } from "history";
// Commons
import Header from "./common/Header";
import Nav from "./common/Nav";
// Containers
import Home from "./home/Home";
import Dashboard from "./dashboard/Dashboard";

const history = createBrowserHistory();

class App extends Component {
	render() {
		return (
			<Router history={history}>
					<Header />
					<div className="main">
						<Nav />
						<div className="content">
							<Switch>
								<Route
									exact
									path={"/"} 
									component={Home}
								/>
								<Route
									path={"/home"} 
									component={Home}
								/>
								<Route
									path={"/dashboard"}
									component={Dashboard}
								/>
							</Switch>
						</div>
					</div>
			</Router>
		);
	}
}

export default App;
