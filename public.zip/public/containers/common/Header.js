import React from "react";

const Header = () => {
	return (
		<div className="header">
			<p><h4>INTERNET OF THINGS</h4></p>
		</div>
	);
};

export default Header;
