import React from "react";
import { NavLink } from "react-router-dom";

const Nav = () => {
	return (
		<div className="nav">
			<ul>
				<li>
					<NavLink to={"/home"}>
						<a>
							<i class="large material-icons">home</i>
							<span><b>Home</b></span>
						</a>
					</NavLink>
				</li>
				<li>
					<NavLink to={"/dashboard"}>
						<a>
							<i class="large material-icons">insert_chart</i>
							<span><b>Dashboard</b></span>
						</a>
					</NavLink>
				</li>
			</ul>
		</div>
	);
};

export default Nav;
