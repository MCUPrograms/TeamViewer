const initialState = {};

function dashboard(state = initialState, action) {
	switch (action.type) {
		default:
			return state;
	}
}

export default dashboard;
