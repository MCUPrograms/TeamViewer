import { combineReducers } from "redux";
import dashboard from "./dashboard";

export default combineReducers({
	dashboard,
});
